<?php 

$dbServerName = "localhost";
$dbUserName = "root";
$dbPassword = "";
$dbName = "sql2241356";

$conn = mysqli_connect($dbServerName, $dbUserName, $dbPassword, $dbName);