<?php

include_once 'dbh.inc.php';
$uname = mysqli_real_escape_string($conn, $_post)$_post['uname'];
$psw = mysqli_real_escape_string($conn, $_post)$_post['psw'];

//error handlers
//checking for empty fields
if (empty($uname) || empty($psw))
{
    header("location: ../loginSetup.html?signup=empty") 
        exit();
}
else
{ //check if characters are valid
    if(!preg_match("/^[a-zA-Z]*$/", $uname))
    {  
        header("location: ../loginSetup.html?signup=invalid") 
            exit();
        else
        { 
        //check if username is original
            $sql = "SELECT * FROM user WHERE user_id = '$uname'";
            $result = mysqli_query($conn, $sql);
            $resultCheck = mysqli_num_row();
            
            if($resultCheck > 0)
            {
                header("location: ../loginSetup.html?signup=usernametaken") 
            exit();
                
            }
            else
            {//Hashing the password
               $hashedPsw = password_hash($psw, PASSWORD_DEFAULT); 
                //Insert the user into the database
                $sql = "INSERT INTO user (user_uname, user_psw) VALUES ('$uname', '$hashedpsw');"; 
                mysqli_query($conn, $sql);
                
                header("location: ../loginSetup.html?signup=success") 
            exit();
            }
        }
    }
}

